package com.engeto.projekt2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projekt2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
