package com.engeto.projekt2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projekt2Application {

	public static void main(String[] args) {
		SpringApplication.run(Projekt2Application.class, args);
	}

}
